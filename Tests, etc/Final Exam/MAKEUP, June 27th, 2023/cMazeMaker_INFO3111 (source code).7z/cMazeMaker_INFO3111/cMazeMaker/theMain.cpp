#include <iostream>
#include "cMazeMaker.h"
#include <sstream>

int main( int argc, char* arv[])
{
	std::cout << "What's your student numbmer? ";
	int SN = 0;
	std::cin >> SN;

	cMazeMaker theMaze(SN);

	theMaze.GenerateMaze(16, 16);

	std::cout << "Your SN is: " << SN << std::endl;
	std::cout << "Your  maze is: " << std::endl;
	std::cout << std::endl;
	theMaze.PrintMaze();

	std::stringstream ssFileName;
	ssFileName << "INFO_3111_Maze_" << SN << ".txt";
	theMaze.PrintMazeToFile_INFO3111(SN, ssFileName.str(), 'X', '.');




	return 0;
}
